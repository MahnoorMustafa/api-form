
import './App.css';

import Signup from './Component/Sign-up form';




function App() {
 return (
   <div>
    <Signup/>
   </div>
  );
}

export default App;
